#include <Servo.h>

int x_pin = A0;
int y_pin = A1;
int sw_pin = 2;
int position = 0;

Servo myServo;

void setup()
{
  Serial.begin(9600);
  pinMode(x_pin, INPUT);
  pinMode(y_pin, INPUT);
  pinMode(sw_pin, INPUT);
  digitalWrite(sw_pin, LOW);

  myServo.attach(3);
  myServo.write(position);
}

void loop()
{
  int x_data = analogRead(x_pin);
  int y_data = analogRead(y_pin);
  int sw_data = digitalRead(sw_pin);

  Serial.print("x_data: ");
  Serial.print(x_data);
  Serial.print("\t");
  Serial.print("y_data: ");
  Serial.print(y_data);
  Serial.print("\t");
  Serial.print("sw_data: ");
  Serial.println(sw_data);
  delay(100);

  if (x_data >= 550)
  {
    if (position <= 180)
    {
      position = position + 20;
      myServo.write(position);
    }
  }
  else if (x_data <= 500)
  {
    if (position >= 0)
    {
      position = position - 20;
      myServo.write(position);
    }
  }
}